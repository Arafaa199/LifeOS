# Finance Features - Complete Setup Guide

## Overview

The Nexus finance module now includes comprehensive expense tracking, budgeting, and analytics features:

### Mobile App Features ✅

1. **Quick Expense Logging**: Natural language expense entry ("$45 at Whole Foods")
2. **Manual Expense Entry**: Detailed form for adding transactions
3. **Budget Management**: Set monthly budgets by category
4. **Budget Alerts**: Visual warnings when approaching or exceeding budgets
5. **Spending Charts**: Pie and bar charts showing category breakdown
6. **CSV Export**: Export all transactions to CSV file
7. **Multi-Currency Support**: AED, SAR, JOD with auto-detection
8. **SMS Auto-Import**: Automatic transaction import from bank SMS (event-based)

### Backend Webhooks Created

All webhooks are located in `/Users/rafa/Cyber/Infrastructure/Nexus-setup/n8n-workflows/`

#### 1. Finance Summary (`finance-summary-webhook.json`)
- **Endpoint**: `GET /webhook/nexus-finance-summary`
- **Returns**:
  - Today's total spending
  - Grocery and restaurant spending
  - Recent transactions (last 30 days, limit 100)
  - Current month budgets with spending progress
  - Category breakdown for current month
  - Currency (AED/SAR/JOD)

#### 2. Set Budget (`budget-set-webhook.json`)
- **Endpoint**: `POST /webhook/nexus-set-budget`
- **Body**: `{ "category": "Grocery", "amount": 3000 }`
- **Action**: Creates or updates budget for current month
- **Returns**: Budget with current spending

#### 3. Fetch Budgets (`budget-fetch-webhook.json`)
- **Endpoint**: `GET /webhook/nexus-budgets`
- **Returns**: All budgets for current month with spending data

#### 4. Delete Budget (`budget-delete-webhook.json`)
- **Endpoint**: `DELETE /webhook/nexus-budget/:id`
- **Returns**: Success message

#### 5. Expense Logging (`expense-log-webhook.json`) - Already exists
- **Endpoint**: `POST /webhook/nexus-expense`
- **Body**: `{ "text": "$45 at Whole Foods" }`
- **Uses**: Claude AI to parse natural language into structured transaction

#### 6. Manual Transaction (`POST /webhook/nexus-transaction`) - Already exists
- Used by AddExpenseView for manual entries

## Setup Instructions

### 1. Import n8n Workflows

You need to import the following new workflows into your n8n instance:

```bash
# SSH to your Nexus server
ssh nexus

# The workflows are in /Users/rafa/Cyber/Infrastructure/Nexus-setup/n8n-workflows/
# You need to import these via n8n UI:
# - finance-summary-webhook.json
# - budget-set-webhook.json
# - budget-fetch-webhook.json
# - budget-delete-webhook.json
```

**Import via n8n UI:**
1. Go to https://n8n.rfanw
2. Click "Workflows" → "Import from File"
3. Upload each JSON file
4. Activate each workflow

### 2. Database Schema

Ensure the `finance.budgets` table exists:

```sql
CREATE TABLE IF NOT EXISTS finance.budgets (
    id SERIAL PRIMARY KEY,
    month VARCHAR(7) NOT NULL,  -- Format: YYYY-MM
    category VARCHAR(100) NOT NULL,
    budget_amount DECIMAL(10, 2) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(month, category)
);

CREATE INDEX idx_budgets_month ON finance.budgets(month);
CREATE INDEX idx_budgets_category ON finance.budgets(category);
```

### 3. Mobile App Build

The mobile app code is ready. Build and run:

```bash
cd /Users/rafa/Cyber/Dev/Nexus-mobile
open Nexus.xcodeproj
# Build and run on your device
```

## Features Breakdown

### Budget Alerts

Budget alerts appear at the top of the Quick tab when:
- **Warning (Orange)**: Spent 80-100% of budget
- **Over Budget (Red)**: Spent > 100% of budget

Shows:
- Category name
- Amount over budget OR percentage used
- Visual banner with appropriate color

### CSV Export

Export button (share icon) in Transactions tab toolbar.

**Export includes:**
- Date (YYYY-MM-DD format)
- Merchant name
- Amount (absolute value)
- Currency
- Category
- Subcategory
- Notes

**CSV is properly formatted:**
- Fields with commas/quotes are escaped
- Can be imported into Excel, Google Sheets, etc.
- Filename: `nexus-transactions-<date>.csv`

### Budget Management

**Set Budget:**
1. Go to Finance tab → Budget sub-tab
2. Tap "Set Budgets" (or "Manage" if budgets exist)
3. Tap "+" to add new budget
4. Select category and enter amount (in AED)
5. Budget applies to current month

**Update Budget:**
- Adding a budget for an existing category updates the amount

**Delete Budget:**
- Swipe left on budget in settings
- Tap "Delete"

**Budget Progress:**
- Progress bar shows green when under budget
- Turns red when over budget
- Shows spent/total and remaining amount
- Updates in real-time as transactions are added

### Charts

Available in Budget tab:

**Pie Chart (iOS 16+):**
- Donut chart with percentages
- Color-coded by category
- Interactive legend

**Bar Chart (iOS 16+):**
- Horizontal bars
- Shows AED amounts
- Sorted by spending (highest first)

**Fallback (iOS 15):**
- Custom progress bars with percentages
- Same data, simpler visualization

## API Usage Examples

### Get Finance Summary
```bash
curl https://n8n.rfanw/webhook/nexus-finance-summary
```

### Set a Budget
```bash
curl -X POST https://n8n.rfanw/webhook/nexus-set-budget \
  -H "Content-Type: application/json" \
  -d '{"category": "Grocery", "amount": 3000}'
```

### Log Quick Expense
```bash
curl -X POST https://n8n.rfanw/webhook/nexus-expense \
  -H "Content-Type: application/json" \
  -d '{"text": "45 aed groceries at carrefour"}'
```

### Add Manual Transaction
```bash
curl -X POST https://n8n.rfanw/webhook/nexus-transaction \
  -H "Content-Type: application/json" \
  -d '{
    "merchant_name": "Starbucks",
    "amount": 25.50,
    "category": "Restaurant",
    "notes": "Morning coffee",
    "date": "2026-01-20T10:30:00Z"
  }'
```

## Files Modified/Created

### Mobile App

**New Files:**
- `Nexus/Views/Finance/AddExpenseView.swift` - Manual expense entry form
- `Nexus/Views/Finance/BudgetSettingsView.swift` - Budget management UI
- `Nexus/Views/Finance/SpendingChartsView.swift` - Visual analytics

**Modified Files:**
- `Nexus/Views/Finance/FinanceView.swift` - Added budget alerts, CSV export, ShareSheet
- `Nexus/ViewModels/FinanceViewModel.swift` - Added budget/category data handling
- `Nexus/Models/FinanceModels.swift` - Added budget request/response models
- `Nexus/Services/NexusAPI.swift` - Added budget API methods

### Backend

**New Workflows:**
- `n8n-workflows/finance-summary-webhook.json`
- `n8n-workflows/budget-set-webhook.json`
- `n8n-workflows/budget-fetch-webhook.json`
- `n8n-workflows/budget-delete-webhook.json`

## Next Steps (Optional Enhancements)

1. **Budget Notifications**: Push notifications when going over budget
2. **Spending Trends**: Weekly/monthly spending comparison charts
3. **Recurring Expenses**: Auto-categorize recurring subscriptions
4. **Receipt Scanner**: OCR for receipt photos
5. **Split Expenses**: Share expenses with others
6. **Savings Goals**: Track progress toward financial goals
7. **Investment Tracking**: Portfolio overview

## Troubleshooting

### Budget alerts not showing
- Check that budgets are set for current month
- Verify spending data is populated in summary
- Ensure finance-summary webhook returns budgets array

### CSV export fails
- Check file permissions on device
- Verify transactions array is not empty
- Check for special characters in merchant names (should be escaped)

### Charts not displaying
- iOS 16+ required for native charts
- iOS 15 users see fallback bars
- Check that categoryBreakdown has data

### Backend errors
- Verify all workflows are activated in n8n
- Check PostgreSQL credentials are correct
- Ensure finance.budgets table exists
- Check n8n logs for detailed errors

## Testing Checklist

- [ ] Import all n8n workflows
- [ ] Activate all workflows in n8n
- [ ] Create finance.budgets table
- [ ] Test finance summary endpoint
- [ ] Build and run mobile app
- [ ] Add manual expense
- [ ] Log quick expense
- [ ] Set a budget
- [ ] Verify budget alert appears
- [ ] Export transactions to CSV
- [ ] View spending charts
- [ ] Delete a budget
- [ ] Test SMS auto-import (if configured)

---

**Status**: ✅ All finance features complete and ready for use
**Last Updated**: 2026-01-20
