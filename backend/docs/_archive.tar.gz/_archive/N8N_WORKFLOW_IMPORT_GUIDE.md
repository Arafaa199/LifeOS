# n8n Workflow Import Guide - Step by Step

## Quick Import via Web UI (Easiest Method)

**Time needed**: 10-15 minutes
**URL**: https://n8n.rfanw

---

## Method 1: Web UI Import (Recommended)

### Step 1: Open n8n

1. Open https://n8n.rfanw in your browser
2. Log in if prompted

### Step 2: Import Finance Workflows

For each workflow below, follow these steps:
1. Click **"Add workflow"** (+ button) or **"Workflows"** → **"Import from File"**
2. Select the JSON file
3. Click **"Save"**
4. **Toggle the workflow to "Active"** (very important!)

### Workflows to Import (12 total)

#### ⭐ NEW Workflows (Must Import - 5)

1. **income-webhook.json**
   - Purpose: Track income (salary, freelance, investments)
   - Path: `/Users/rafa/Cyber/Infrastructure/Nexus-setup/n8n-workflows/income-webhook.json`
   - Webhook: `/webhook/nexus-income`

2. **transaction-update-webhook.json**
   - Purpose: Edit existing transactions
   - Path: `/Users/rafa/Cyber/Infrastructure/Nexus-setup/n8n-workflows/transaction-update-webhook.json`
   - Webhook: `/webhook/nexus-update-transaction`

3. **transaction-delete-webhook.json**
   - Purpose: Delete transactions
   - Path: `/Users/rafa/Cyber/Infrastructure/Nexus-setup/n8n-workflows/transaction-delete-webhook.json`
   - Webhook: `/webhook/nexus-delete-transaction`

4. **insights-webhook.json**
   - Purpose: AI-powered spending insights with Claude
   - Path: `/Users/rafa/Cyber/Infrastructure/Nexus-setup/n8n-workflows/insights-webhook.json`
   - Webhook: `/webhook/nexus-insights`

5. **monthly-trends-webhook.json**
   - Purpose: Monthly spending trends (3/6/12 months)
   - Path: `/Users/rafa/Cyber/Infrastructure/Nexus-setup/n8n-workflows/monthly-trends-webhook.json`
   - Webhook: `/webhook/nexus-monthly-trends`

#### 🔄 UPDATED Workflows (Re-import - 3)

6. **budget-set-webhook.json**
   - Purpose: Set monthly budgets (fixed date handling)
   - Path: `/Users/rafa/Cyber/Infrastructure/Nexus-setup/n8n-workflows/budget-set-webhook.json`
   - Webhook: `/webhook/nexus-set-budget`
   - **Action**: Delete old version, import new

7. **budget-fetch-webhook.json**
   - Purpose: Fetch budgets with spending (fixed date handling)
   - Path: `/Users/rafa/Cyber/Infrastructure/Nexus-setup/n8n-workflows/budget-fetch-webhook.json`
   - Webhook: `/webhook/nexus-budgets`
   - **Action**: Delete old version, import new

8. **finance-summary-webhook.json**
   - Purpose: Complete finance summary (added budgets/categories)
   - Path: `/Users/rafa/Cyber/Infrastructure/Nexus-setup/n8n-workflows/finance-summary-webhook.json`
   - Webhook: `/webhook/nexus-finance-summary`
   - **Action**: Delete old version, import new

#### ✅ EXISTING Workflows (Check Only - 4)

9. **expense-log-webhook.json**
   - Webhook: `/webhook/nexus-expense`
   - **Action**: Verify it's active (green toggle)

10. **auto-sms-import.json**
    - **Action**: Verify it's active

11. **trigger-sms-import.json**
    - Webhook: `/webhook/nexus-trigger-import`
    - **Action**: Verify it's active

12. **budget-delete-webhook.json**
    - Webhook: `/webhook/nexus-budget`
    - **Action**: Verify it's active

---

## Method 2: API Import (Advanced)

If you prefer to use the API:

### Step 1: Get API Key

1. Open https://n8n.rfanw
2. Go to **Settings** → **API**
3. Click **"Create API Key"**
4. Copy the key

### Step 2: Run Import Script

```bash
cd /Users/rafa/Cyber/Infrastructure/Nexus-setup
./import-n8n-workflows.sh [YOUR_API_KEY]
```

The script will:
- Check which workflows exist
- Prompt before updating existing ones
- Import new workflows
- Activate all workflows automatically
- Show a summary at the end

---

## Verification Checklist

After importing, verify all workflows are working:

### 1. Check All Workflows are Active

In n8n UI:
- [ ] All 12 finance workflows visible
- [ ] All have **green "Active" toggle**
- [ ] No error badges on any workflow

### 2. Test Each Webhook

From terminal:

```bash
# Test expense logging
curl -X POST https://n8n.rfanw/webhook/nexus-expense \
  -H "Content-Type: application/json" \
  -d '{"text": "25 test coffee"}' | jq .

# Expected: {"success": true, "message": "Expense logged..."}

# Test income tracking
curl -X POST https://n8n.rfanw/webhook/nexus-income \
  -H "Content-Type: application/json" \
  -d '{
    "source": "Test Income",
    "amount": 100,
    "category": "Salary",
    "date": "2026-01-20T10:00:00Z",
    "is_recurring": false
  }' | jq .

# Expected: {"success": true, "message": "Income added..."}

# Test budget fetch
curl https://n8n.rfanw/webhook/nexus-budgets | jq .

# Expected: {"success": true, "data": {...}}

# Test finance summary
curl https://n8n.rfanw/webhook/nexus-finance-summary | jq .

# Expected: {"success": true, "data": {"totalSpent": ...}}

# Test AI insights
curl -X POST https://n8n.rfanw/webhook/nexus-insights \
  -H "Content-Type: application/json" \
  -d '{"summary": "Total spent: AED 500, Categories: Food AED 200, Transport AED 100"}' | jq .

# Expected: {"success": true, "data": {"insights": "..."}}

# Test monthly trends
curl 'https://n8n.rfanw/webhook/nexus-monthly-trends?months=3' | jq .

# Expected: {"success": true, "data": {"trends": [...]}}

# Test transaction update
curl -X POST https://n8n.rfanw/webhook/nexus-update-transaction \
  -H "Content-Type: application/json" \
  -d '{
    "id": 1,
    "merchantName": "Test Updated",
    "amount": 50,
    "category": "Food",
    "date": "2026-01-20T10:00:00Z"
  }' | jq .

# Expected: {"success": true, "message": "Transaction updated..."}

# Test transaction delete
curl -X DELETE 'https://n8n.rfanw/webhook/nexus-delete-transaction?id=999' | jq .

# Expected: {"success": true, "message": "Transaction deleted..."} or error if ID doesn't exist
```

### 3. Test from Mobile App

1. Open Nexus app in Xcode
2. Run on simulator/device
3. Try each feature:
   - [ ] Log expense: "25 coffee at starbucks"
   - [ ] Add income: Salary, 10000 AED
   - [ ] View transactions list
   - [ ] Edit a transaction
   - [ ] Delete a transaction
   - [ ] Set a budget
   - [ ] Generate AI insights
   - [ ] View monthly trends

All should work without errors!

---

## Troubleshooting

### Workflow won't import
- **Error**: "Workflow with same name exists"
- **Fix**: Delete old workflow first, then import new one

### Webhook returns 404
- **Check**: Workflow is activated (green toggle)
- **Check**: Webhook path matches in workflow
- **Fix**: Deactivate and reactivate workflow

### PostgreSQL credentials error in workflow
- **Check**: Postgres credentials in n8n match:
  - Host: `nexus-db` or the actual IP of nexus server
  - Port: `5432`
  - Database: `nexus`
  - User: `nexus`
  - Password: `XRtRxHAtSXCYK2OLK2C9Fu8Ak6PhuwiI`

### Workflow executes but returns error
- **Check**: n8n execution logs (click on workflow → Executions tab)
- **Look for**: SQL errors, connection errors, missing fields
- **Common fix**: Update database credentials in workflow nodes

---

## Expected Webhook URLs

After import, these endpoints should be active:

```
https://n8n.rfanw/webhook/nexus-expense          (POST)
https://n8n.rfanw/webhook/nexus-income           (POST)
https://n8n.rfanw/webhook/nexus-update-transaction (POST)
https://n8n.rfanw/webhook/nexus-delete-transaction (DELETE)
https://n8n.rfanw/webhook/nexus-set-budget       (POST)
https://n8n.rfanw/webhook/nexus-budgets          (GET)
https://n8n.rfanw/webhook/nexus-budget?id=X      (DELETE)
https://n8n.rfanw/webhook/nexus-finance-summary  (GET)
https://n8n.rfanw/webhook/nexus-insights         (POST)
https://n8n.rfanw/webhook/nexus-monthly-trends   (GET)
https://n8n.rfanw/webhook/nexus-trigger-import   (POST)
```

---

## Success Criteria

✅ **You're done when**:
- All 12 workflows imported
- All 12 workflows activated (green toggle)
- All webhook endpoints return `{"success": true}`
- Mobile app can add/edit/delete transactions
- AI insights generate successfully
- No errors in n8n execution logs

---

## Next Steps After Import

1. **Test the mobile app thoroughly** (see testing checklist in FINAL_DEPLOYMENT.md)
2. **Delete test transactions** created during testing
3. **Set real budgets** for your actual spending
4. **Start using the app** for real finance tracking!

---

**Import Time**: 10-15 minutes
**Difficulty**: Easy (web UI) or Medium (API)
**Files Location**: `/Users/rafa/Cyber/Infrastructure/Nexus-setup/n8n-workflows/`
**Last Updated**: 2026-01-20
