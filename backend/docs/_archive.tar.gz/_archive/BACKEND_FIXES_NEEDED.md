# Backend Fixes Needed - Quick Reference

## Critical Issue: NocoDB Not Working ❌

**Problem**: NocoDB can't connect to PostgreSQL
**Cause**: Wrong hostname in connection string (`postgres` instead of `nexus-db`)

### Quick Fix (5 minutes):

```bash
# Option 1: Run the fix script
scp fix-nocodb.sh nexus:~/
ssh nexus "bash ~/fix-nocodb.sh"

# Option 2: Manual fix
ssh nexus
cd ~/nexus-setup  # Or wherever your docker-compose.yml is
nano docker-compose.yml
# Find: pg://postgres:5432
# Replace with: pg://nexus-db:5432
docker compose restart nocodb
```

---

## n8n Workflow Setup ⚠️

**Status**: n8n is NOT on nexus server (must be at https://n8n.rfanw)

### Action Required:
1. Go to https://n8n.rfanw
2. Import these 12 workflows from `/Users/rafa/Cyber/Infrastructure/Nexus-setup/n8n-workflows/`:
   - ✅ Already imported (no changes needed):
     - expense-log-webhook.json
     - auto-sms-import.json
     - trigger-sms-import.json
     - budget-delete-webhook.json
   - ⭐ Must re-import (updated):
     - budget-set-webhook.json
     - budget-fetch-webhook.json
     - finance-summary-webhook.json
   - ⭐ Must import (new):
     - transaction-update-webhook.json
     - transaction-delete-webhook.json
     - insights-webhook.json
     - monthly-trends-webhook.json
     - income-webhook.json
3. **IMPORTANT**: Activate ALL 12 workflows (click the toggle)
4. Test each webhook endpoint

---

## Database Optimization (Optional)

### Clean Up NocoDB Clutter

NocoDB has created multiple test schemas that are cluttering your database:

```bash
ssh nexus "docker exec -it nexus-db psql -U nexus -d nexus"
```

```sql
-- See all schemas
SELECT schema_name, pg_size_pretty(sum(pg_total_relation_size(quote_ident(schemaname) || '.' || quote_ident(tablename)))::bigint) as size
FROM pg_tables
WHERE schemaname NOT IN ('pg_catalog', 'information_schema')
GROUP BY schema_name
ORDER BY sum(pg_total_relation_size(quote_ident(schemaname) || '.' || quote_ident(tablename))) DESC;

-- Drop unused NocoDB schemas (BACKUP FIRST!)
-- Only if you're sure they're not needed
DROP SCHEMA IF EXISTS p7bn7ob21an8qle CASCADE;
DROP SCHEMA IF EXISTS pbl55w5g1y3au6y CASCADE;
DROP SCHEMA IF EXISTS p0tfqw50uv07rxs CASCADE;
DROP SCHEMA IF EXISTS pbhrgwiqy21sjx5 CASCADE;
```

### Add Missing Column (Optional)

For recurring transaction detection to work best:

```sql
ALTER TABLE finance.transactions
ADD COLUMN IF NOT EXISTS is_recurring BOOLEAN DEFAULT false;
```

---

## What's Working Well ✅

- PostgreSQL 16 running perfectly
- Backups working flawlessly (daily at 3 AM, keeps 7 days)
- Good database schema with proper indexes
- Triggers for auto-categorization working
- 91 transactions successfully stored
- Resource limits properly configured

---

## TimescaleDB: Do You Need It?

**Answer: NO, not yet**

**Current status**:
- Only 91 transactions over 358 days
- Database size: 256KB
- Queries are fast (< 10ms)
- Current indexes handle everything efficiently

**Install TimescaleDB when**:
- You have > 500 transactions
- You need complex time-series aggregations
- Query performance starts to degrade
- You want continuous aggregates for monthly summaries

**Bottom line**: Your current PostgreSQL setup is perfect for your data volume. Don't over-engineer it.

---

## Summary Checklist

### Must Do Today:
- [ ] Fix NocoDB connection (run fix-nocodb.sh)
- [ ] Verify NocoDB accessible at http://localhost:8080

### Must Do This Week:
- [ ] Import 5 new n8n workflows
- [ ] Re-import 3 updated n8n workflows
- [ ] Activate all 12 workflows
- [ ] Test all webhook endpoints from the mobile app

### Optional This Week:
- [ ] Add is_recurring column to transactions table
- [ ] Clean up unused NocoDB schemas

### Not Needed:
- ❌ TimescaleDB installation (too early)
- ❌ Table partitioning (data volume too small)
- ❌ Complex query optimization (already fast)

---

## Testing After Fixes

### 1. Test NocoDB
```bash
# Should return OK
curl http://localhost:8080/api/v1/health
```

### 2. Test n8n Workflows

From your Mac (or test with curl):
```bash
# Test expense logging
curl -X POST https://n8n.rfanw/webhook/nexus-expense \
  -H "Content-Type: application/json" \
  -d '{"text": "25 coffee at starbucks"}'

# Test income tracking
curl -X POST https://n8n.rfanw/webhook/nexus-income \
  -H "Content-Type: application/json" \
  -d '{
    "source": "Test Salary",
    "amount": 10000,
    "category": "Salary",
    "notes": "Testing",
    "date": "2026-01-20T10:00:00Z",
    "is_recurring": true
  }'

# Test budget fetch
curl https://n8n.rfanw/webhook/nexus-budgets

# Test finance summary
curl https://n8n.rfanw/webhook/nexus-finance-summary
```

All should return `{"success": true, ...}`

### 3. Test Mobile App

1. Open app in Xcode
2. Run on simulator/device
3. Try each feature:
   - Log expense (Quick tab)
   - Add income (green button)
   - View transactions
   - Set a budget
   - Generate AI insights
   - View monthly trends
4. All should work without errors

---

## Files Created

1. **BACKEND_ASSESSMENT.md** - Complete 500+ line analysis
2. **fix-nocodb.sh** - Automated fix script
3. **BACKEND_FIXES_NEEDED.md** - This quick reference

---

## Next Steps

1. Run the NocoDB fix: `ssh nexus "bash ~/fix-nocodb.sh"`
2. Import n8n workflows at https://n8n.rfanw
3. Test the mobile app
4. If everything works: ✅ **You're production ready!**

---

**Last Updated**: 2026-01-20
**Backend Status**: B+ (Good, minor fixes needed)
**Production Ready**: After NocoDB fix + n8n workflow import
