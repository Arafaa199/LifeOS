# Fix n8n.rfanw Access via Tailscale

## Problem
- n8n.rfanw works on LAN but not via Tailscale when remote
- Caddy root certificate already installed on iPhone
- TLS error when connecting from outside LAN

## Root Cause
Caddy is only listening on the LAN interface (10.0.0.11) and not on the Tailscale interface (100.90.189.16).

---

## Solution: Configure Caddy to Listen on All Interfaces

### Step 1: Update Caddy Configuration on Nexus Server

SSH into your nexus server and update the Caddyfile:

```bash
ssh nexus.rfanw  # (or: ssh rafa@100.90.189.16)

# Find the Caddyfile location
# Common locations:
# - /etc/caddy/Caddyfile
# - ~/caddy/Caddyfile
# - Docker volume if running in container

# Check if Caddy is running as Docker container
docker ps | grep caddy
```

### Step 2: Update Caddyfile

Add or update the n8n.rfanw site block:

```caddyfile
# Listen on all interfaces (including Tailscale)
n8n.rfanw {
    bind 0.0.0.0
    reverse_proxy localhost:5678
}
```

If Caddy is running in Docker, the Caddyfile might be in:
```bash
# If in /home/scrypt/caddy directory:
nano /home/scrypt/caddy/Caddyfile

# Add:
n8n.rfanw {
    bind 0.0.0.0
    reverse_proxy n8n:5678  # Use container name if both in same Docker network
}
```

### Step 3: Reload Caddy

**If Caddy is installed directly:**
```bash
sudo systemctl reload caddy
# or
sudo caddy reload --config /etc/caddy/Caddyfile
```

**If Caddy is in Docker:**
```bash
docker restart caddy
# or if using docker compose:
cd ~/caddy && docker compose restart
```

---

## Alternative Solution: Use /etc/hosts on Your Mac

Since iOS syncs with iCloud Keychain, you can set up split DNS using your Mac:

### On Your Mac:
```bash
# Add Tailscale IP for n8n.rfanw when on Tailscale
echo "100.90.189.16 n8n.rfanw" | sudo tee -a /etc/hosts
```

But this won't help iOS unfortunately - iOS doesn't have user-editable hosts file.

---

## Best Solution: Tailscale MagicDNS Override

This makes n8n.rfanw resolve to the Tailscale IP automatically when you're on Tailscale:

### Method 1: Tailscale Admin Console (Easiest)

1. Go to: https://login.tailscale.com/admin/dns
2. Click "Add nameserver" → "Custom"
3. Add:
   - **Nameserver**: `100.90.189.16` (your nexus server)
   - **Restrict to search domain**: `rfanw`
4. Make sure MagicDNS is enabled

This tells Tailscale: "For any .rfanw domains, ask 100.90.189.16 for DNS resolution"

### Method 2: Run DNS on Nexus Server

Install dnsmasq on nexus to serve .rfanw domains:

```bash
ssh nexus.rfanw

# Install dnsmasq
sudo apt install dnsmasq

# Configure
sudo tee /etc/dnsmasq.d/rfanw.conf << EOF
# Respond to .rfanw queries
address=/n8n.rfanw/100.90.189.16
address=/nexus.rfanw/100.90.189.16
# Add other .rfanw domains as needed
EOF

# Restart dnsmasq
sudo systemctl restart dnsmasq

# Test
dig @localhost n8n.rfanw
```

Then in Tailscale admin console, set nexus as nameserver for .rfanw domain.

---

## Verification Steps

### 1. Test DNS Resolution (on Mac with Tailscale):
```bash
# This should return 100.90.189.16
dig n8n.rfanw +short
# or
nslookup n8n.rfanw
```

### 2. Test HTTPS Connection:
```bash
# From your Mac
curl -v https://n8n.rfanw/
# Should get 200 OK, not connection refused
```

### 3. Test from iPhone:
1. Open Settings → General → VPN & Device Management
2. Verify Tailscale is connected
3. Open Nexus app → Settings
4. Set Webhook Base URL to: `https://n8n.rfanw`
5. Tap "Test Connection"
6. Should succeed ✅

---

## Quick Fix While Testing (Temporary)

While you set up the proper solution, use the Tailscale MagicDNS hostname in your iOS app:

**In iPhone Nexus app → Settings:**
- Change "Webhook Base URL" to: `https://nexus.taildae40e.ts.net:5678`

This uses Tailscale's built-in HTTPS certificate, but you'll get a certificate warning. You can ignore it for testing.

---

## Recommended Approach (In Order)

1. **First: Fix Caddy binding** (10 minutes)
   - SSH to nexus
   - Update Caddyfile to `bind 0.0.0.0`
   - Restart Caddy
   - Test: `curl -k https://100.90.189.16/` from your Mac

2. **Then: Set up Tailscale DNS** (5 minutes)
   - Go to Tailscale admin console
   - Add nexus as nameserver for .rfanw domain
   - Or manually add DNS records in Tailscale

3. **Finally: Test on iPhone** (2 minutes)
   - Open Nexus app
   - Settings → Webhook Base URL: `https://n8n.rfanw`
   - Test Connection
   - Should work! ✅

---

## What Each Solution Does

| Solution | Pros | Cons | Setup Time |
|----------|------|------|------------|
| Caddy bind 0.0.0.0 | Works everywhere, uses your cert | Requires server access | 10 min |
| Tailscale DNS override | Clean, automatic | Requires Tailscale admin | 5 min |
| Use Tailscale hostname | No config needed | Different URL, cert warning | 1 min |
| dnsmasq on nexus | Full control | More complex | 20 min |

---

## Debugging Commands

### Check Caddy Status:
```bash
ssh nexus.rfanw
sudo systemctl status caddy
# or for Docker:
docker logs caddy -f
```

### Check what ports Caddy is listening on:
```bash
ssh nexus.rfanw
sudo netstat -tlnp | grep caddy
# or
sudo ss -tlnp | grep caddy

# Should show:
# 0.0.0.0:80  (all interfaces, HTTP)
# 0.0.0.0:443 (all interfaces, HTTPS)
```

### Test n8n directly (bypassing Caddy):
```bash
# From your Mac via Tailscale
curl http://100.90.189.16:5678
# Should return n8n web interface HTML
```

### Test Caddy via Tailscale IP:
```bash
# From your Mac
curl -k https://100.90.189.16/
# Should proxy to n8n, or return 404 if not configured
```

---

## Files to Check/Modify

1. **Caddyfile** - Add/update n8n.rfanw block with `bind 0.0.0.0`
2. **docker-compose.yml** (if Caddy is in Docker) - Ensure ports mapped correctly
3. **Tailscale DNS settings** - Add nameserver override for .rfanw
4. **iOS app settings** - Update Webhook Base URL

---

## Expected Result

After implementing the fix:

✅ n8n.rfanw works on LAN (as before)
✅ n8n.rfanw works via Tailscale when remote
✅ Uses your existing Caddy certificate (no warnings)
✅ Seamless experience regardless of location

Let me know which solution you'd like to implement first!
