# n8n Installation Complete!

## Quick Access

**n8n is now running!**

**Access URLs**:
- Direct (Tailscale): `http://nexus:5678` or `http://100.90.189.16:5678`
- Future (with reverse proxy): `https://n8n.rfanw`

**Login Credentials**:
- Username: `admin`
- Password: `nexusadmin123`

---

## What Was Done

### 1. n8n Installation
- Installed n8n via Docker on nexus server
- Container name: `n8n`
- Port: `5678`
- Data stored in: Docker volume `n8n_data`
- Location: `/home/scrypt/n8n-setup/docker-compose.yml`

### 2. Container Status
```bash
ssh nexus "docker ps | grep n8n"
# Result: Up and running on port 5678
```

### 3. Verification
```bash
curl http://nexus:5678
# Returns: HTTP 200 OK (n8n web interface)
```

---

## Next Steps (Required)

### Step 1: First-Time Setup (5 minutes)
1. Open `http://nexus:5678` in your browser (or `http://100.90.189.16:5678`)
2. Create owner account (first-time setup)
3. Skip the tutorial (or complete it if you want)

### Step 2: Create API Key (Required for workflow import)
1. In n8n, click your profile (top right)
2. Click "Settings"
3. Go to "API" section
4. Click "Create API Key"
5. Name it: "Nexus Workflow Import"
6. Copy the API key
7. Update the import script:
   ```bash
   # Edit this file:
   nano /Users/rafa/Cyber/Infrastructure/Nexus-setup/scripts/import-workflows-final.sh

   # Replace the API_KEY value (line 5) with your new key
   # Replace N8N_URL (line 6) with: http://nexus:5678
   ```

### Step 3: Import Workflows (10 minutes)
```bash
cd /Users/rafa/Cyber/Infrastructure/Nexus-setup/scripts
./import-workflows-final.sh
```

This will import all 12 finance workflows.

### Step 4: Configure PostgreSQL Credential (5 minutes)
1. In n8n, click "Settings" → "Credentials"
2. Click "Add Credential"
3. Search for "Postgres" and select it
4. Fill in:
   - Name: `Nexus PostgreSQL`
   - Host: `100.90.189.16` (or `nexus.rfanw` if DNS works)
   - Port: `5432`
   - Database: `nexus`
   - User: `nexus`
   - Password: `XRtRxHAtSXCYK2OLK2C9Fu8Ak6PhuwiI`
   - SSL: Disable
5. Click "Test" (should succeed)
6. Click "Save"

**Important**: Note the credential ID (should be "1" or similar)

### Step 5: Update Mobile App (1 minute)
The mobile app currently points to https://n8n.rfanw which doesn't work.

**Temporary fix** - Update baseURL in Settings or hardcode:
```swift
// In NexusAPI.swift, change baseURL to:
private var baseURL: String {
    "http://100.90.189.16:5678"  // Use IP instead of domain
}
```

**Or** update UserDefaults:
```bash
# For simulator:
xcrun simctl spawn booted defaults write com.yourcompany.Nexus webhookBaseURL "http://100.90.189.16:5678"
```

---

## Optional: Set Up Reverse Proxy (For https://n8n.rfanw)

If you want to use the domain name `n8n.rfanw` instead of IP:port, you need a reverse proxy.

### Option A: Caddy (Recommended)
```bash
# Install Caddy on nexus server
ssh nexus
sudo apt install -y debian-keyring debian-archive-keyring apt-transport-https
curl -1sLf 'https://dl.cloudsmith.io/public/caddy/stable/gpg.key' | sudo gpg --dearmor -o /usr/share/keyrings/caddy-stable-archive-keyring.gpg
curl -1sLf 'https://dl.cloudsmith.io/public/caddy/stable/debian.deb.txt' | sudo tee /etc/apt/sources.list.d/caddy-stable.list
sudo apt update
sudo apt install caddy

# Configure Caddyfile
sudo cat > /etc/caddy/Caddyfile <<EOF
n8n.rfanw {
    reverse_proxy localhost:5678
}
EOF

# Reload Caddy
sudo systemctl reload caddy
```

### Option B: nginx
```bash
# Install nginx
ssh nexus
sudo apt install nginx

# Create config
sudo cat > /etc/nginx/sites-available/n8n <<EOF
server {
    listen 80;
    server_name n8n.rfanw;

    location / {
        proxy_pass http://localhost:5678;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
    }
}
EOF

# Enable and reload
sudo ln -s /etc/nginx/sites-available/n8n /etc/nginx/sites-enabled/
sudo systemctl reload nginx
```

---

## Troubleshooting

### Can't access n8n web interface
```bash
# Check if container is running
ssh nexus "docker ps | grep n8n"

# Check n8n logs
ssh nexus "docker logs n8n"

# Restart if needed
ssh nexus "cd ~/n8n-setup && docker compose restart"
```

### Workflows not working
- Make sure PostgreSQL credential is configured
- Check that workflows are activated (toggle in top-right)
- Test individual nodes in workflow editor

### Mobile app can't connect
- Verify baseURL is set to correct IP:port
- Test webhook manually with curl:
  ```bash
  curl -X POST http://100.90.189.16:5678/webhook/nexus-finance-summary
  ```

---

## Container Management

### Start/Stop n8n
```bash
ssh nexus "cd ~/n8n-setup && docker compose up -d"     # Start
ssh nexus "cd ~/n8n-setup && docker compose stop"      # Stop
ssh nexus "cd ~/n8n-setup && docker compose restart"   # Restart
ssh nexus "cd ~/n8n-setup && docker compose down"      # Stop and remove
```

### View logs
```bash
ssh nexus "docker logs -f n8n"  # Follow logs
ssh nexus "docker logs n8n --tail 100"  # Last 100 lines
```

### Backup n8n data
```bash
# Backup workflow data
ssh nexus "docker exec n8n tar czf /tmp/n8n-backup.tar.gz /home/node/.n8n"
scp nexus:/tmp/n8n-backup.tar.gz ~/backups/n8n-backup-$(date +%Y%m%d).tar.gz
```

---

## Summary

✅ n8n installed and running
✅ Accessible at http://nexus:5678
⏳ Needs first-time setup (create owner account)
⏳ Needs API key for workflow import
⏳ Needs PostgreSQL credential configuration
⏳ Workflows need to be imported
⏳ Mobile app needs baseURL update

**Total time remaining**: ~25 minutes of manual work

**Current Status**: n8n is installed, but requires web UI setup before it can be used
