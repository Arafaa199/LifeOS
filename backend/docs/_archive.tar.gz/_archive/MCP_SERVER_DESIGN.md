# Nexus MCP Server - Intelligent Data Access for Claude Code

## Overview

Build a **Model Context Protocol (MCP) server** that gives Claude Code structured, intelligent access to your Nexus data directly from your terminal.

**What is MCP?**
- Official protocol by Anthropic for LLM-application integration
- Allows Claude to call tools and query data semantically
- Built into Claude Code CLI
- Better than raw SQL or data dumps - provides **context-aware operations**

---

## What This Enables 🚀

### Natural Conversations with Your Data

Instead of this:
```bash
# ❌ Old way: Manual queries
ssh nexus "docker exec nexus-db psql -U nexus -d nexus -c 'SELECT...'"
```

You get this:
```bash
# ✅ New way: Natural language
claude
> How much did I spend on food last month?
> Show me my biggest expenses this week
> What are my recurring subscriptions?
> Am I over budget in any category?
> Predict my spending for next month
> Find unusual transactions
```

**Claude automatically**:
- Queries the right data
- Analyzes trends
- Provides insights
- Suggests optimizations
- Answers follow-up questions

---

## Architecture

```
Your Terminal (Claude Code CLI)
    ↓
MCP Server (nexus-mcp)
    ↓
PostgreSQL Database (nexus-db)
    ↓
Structured Data Response
    ↓
Claude Analysis & Insights
```

---

## MCP Server Tools (Semantic Operations)

### Finance Queries

1. **get_spending_summary**
   - Input: `{period: "month" | "week" | "year"}`
   - Output: Total spent, by category, top merchants

2. **get_transactions**
   - Input: `{start_date, end_date, category?, merchant?, min_amount?, max_amount?}`
   - Output: Filtered transaction list with metadata

3. **get_budget_status**
   - Input: `{month?: "current"}`
   - Output: All budgets with spent/remaining/percentage

4. **get_category_breakdown**
   - Input: `{period: "month" | "week" | "year"}`
   - Output: Spending by category with percentages

5. **get_recurring_patterns**
   - Input: `{min_occurrences?: 3}`
   - Output: Detected recurring transactions/subscriptions

6. **get_merchant_analysis**
   - Input: `{merchant?: string, top_n?: 10}`
   - Output: Spending by merchant with frequency

7. **predict_spending**
   - Input: `{period: "next_month" | "next_week"}`
   - Output: ML-based prediction based on historical data

8. **detect_anomalies**
   - Input: `{threshold?: 2.0}` (standard deviations)
   - Output: Unusual transactions flagged

9. **get_income_summary**
   - Input: `{period: "month" | "year"}`
   - Output: Total income, by category, recurring vs one-time

10. **get_net_worth_trend**
    - Input: `{months: 3 | 6 | 12}`
    - Output: Income - expenses over time

### Health Queries (Future)

11. **get_health_metrics**
12. **get_nutrition_summary**
13. **get_activity_trends**

---

## Implementation

### Option 1: TypeScript MCP Server (Recommended)

**Advantages**:
- Official Anthropic SDK support
- Easy to extend
- Type-safe
- Can add caching, rate limiting, etc.

**Stack**:
- `@modelcontextprotocol/sdk` - Official MCP SDK
- `pg` - PostgreSQL client
- TypeScript for type safety

**File Structure**:
```
nexus-mcp/
├── package.json
├── tsconfig.json
├── src/
│   ├── index.ts           # MCP server entry point
│   ├── tools/
│   │   ├── finance.ts     # Finance-related tools
│   │   ├── health.ts      # Health-related tools (future)
│   │   └── analytics.ts   # Advanced analytics
│   ├── db/
│   │   ├── client.ts      # PostgreSQL connection
│   │   └── queries.ts     # SQL queries
│   └── utils/
│       ├── cache.ts       # Optional caching
│       └── validators.ts  # Input validation
├── README.md
└── .env.example
```

### Option 2: Python MCP Server (Alternative)

**Advantages**:
- Great for ML/analytics (pandas, scikit-learn)
- Easy data manipulation
- Rich ecosystem for data analysis

**Stack**:
- `mcp` - Python MCP SDK
- `psycopg2` - PostgreSQL client
- `pandas` - Data analysis
- `scikit-learn` - ML predictions

---

## Quick Start Implementation

### Step 1: Install MCP SDK

```bash
mkdir ~/nexus-mcp
cd ~/nexus-mcp
npm init -y
npm install @modelcontextprotocol/sdk pg dotenv
npm install -D typescript @types/node @types/pg
npx tsc --init
```

### Step 2: Create Basic MCP Server

**File: `src/index.ts`**

```typescript
import { Server } from '@modelcontextprotocol/sdk/server/index.js';
import { StdioServerTransport } from '@modelcontextprotocol/sdk/server/stdio.js';
import { Pool } from 'pg';

const pool = new Pool({
  host: process.env.DB_HOST || 'nexus.rfanw',
  port: parseInt(process.env.DB_PORT || '5432'),
  database: process.env.DB_NAME || 'nexus',
  user: process.env.DB_USER || 'nexus',
  password: process.env.DB_PASSWORD,
});

const server = new Server(
  {
    name: 'nexus-mcp',
    version: '1.0.0',
  },
  {
    capabilities: {
      tools: {},
    },
  }
);

// Tool: Get Spending Summary
server.setRequestHandler('tools/call', async (request) => {
  if (request.params.name === 'get_spending_summary') {
    const { period = 'month' } = request.params.arguments || {};

    let dateFilter = '';
    if (period === 'month') {
      dateFilter = "date >= date_trunc('month', CURRENT_DATE)";
    } else if (period === 'week') {
      dateFilter = "date >= date_trunc('week', CURRENT_DATE)";
    }

    const result = await pool.query(`
      SELECT
        COUNT(*) as transaction_count,
        SUM(CASE WHEN amount < 0 THEN ABS(amount) ELSE 0 END) as total_spent,
        SUM(CASE WHEN amount > 0 THEN amount ELSE 0 END) as total_income,
        category,
        SUM(CASE WHEN amount < 0 THEN ABS(amount) ELSE 0 END) as category_spent
      FROM finance.transactions
      WHERE ${dateFilter}
      GROUP BY category
      ORDER BY category_spent DESC
    `);

    return {
      content: [
        {
          type: 'text',
          text: JSON.stringify(result.rows, null, 2),
        },
      ],
    };
  }

  // Add more tools here...

  throw new Error(`Unknown tool: ${request.params.name}`);
});

// List available tools
server.setRequestHandler('tools/list', async () => {
  return {
    tools: [
      {
        name: 'get_spending_summary',
        description: 'Get spending summary for a time period',
        inputSchema: {
          type: 'object',
          properties: {
            period: {
              type: 'string',
              enum: ['month', 'week', 'year'],
              description: 'Time period to analyze',
            },
          },
        },
      },
      // Add more tool definitions...
    ],
  };
});

async function main() {
  const transport = new StdioServerTransport();
  await server.connect(transport);
  console.error('Nexus MCP server running on stdio');
}

main().catch(console.error);
```

### Step 3: Configure Claude Code to Use MCP Server

**File: `~/.claude/config.json`**

```json
{
  "mcpServers": {
    "nexus": {
      "command": "node",
      "args": ["/Users/rafa/nexus-mcp/dist/index.js"],
      "env": {
        "DB_HOST": "nexus.rfanw",
        "DB_PORT": "5432",
        "DB_NAME": "nexus",
        "DB_USER": "nexus",
        "DB_PASSWORD": "XRtRxHAtSXCYK2OLK2C9Fu8Ak6PhuwiI"
      }
    }
  }
}
```

### Step 4: Use from Claude Code CLI

```bash
claude

> How much did I spend on food this month?

# Claude automatically calls get_spending_summary tool
# Analyzes the data
# Provides natural language response
```

---

## Advanced Features

### 1. Caching Layer

**Add Redis caching** for expensive queries:

```typescript
import Redis from 'ioredis';

const redis = new Redis(process.env.REDIS_URL);

async function getCachedOrQuery(key: string, queryFn: () => Promise<any>, ttl = 300) {
  const cached = await redis.get(key);
  if (cached) return JSON.parse(cached);

  const result = await queryFn();
  await redis.setex(key, ttl, JSON.stringify(result));
  return result;
}
```

### 2. Predictive Analytics

**Add ML predictions** using historical data:

```typescript
import * as tf from '@tensorflow/tfjs-node';

async function predictNextMonthSpending(category: string): Promise<number> {
  // Get last 12 months of data
  const history = await pool.query(`
    SELECT DATE_TRUNC('month', date) as month, SUM(ABS(amount)) as total
    FROM finance.transactions
    WHERE category = $1 AND amount < 0
    AND date >= NOW() - INTERVAL '12 months'
    GROUP BY month
    ORDER BY month
  `, [category]);

  // Simple linear regression (can upgrade to LSTM later)
  const xs = history.rows.map((_, i) => i);
  const ys = history.rows.map(r => r.total);

  const model = tf.sequential();
  model.add(tf.layers.dense({ units: 1, inputShape: [1] }));
  model.compile({ loss: 'meanSquaredError', optimizer: 'sgd' });

  await model.fit(tf.tensor2d(xs, [xs.length, 1]), tf.tensor1d(ys), { epochs: 100 });

  const prediction = model.predict(tf.tensor2d([xs.length], [1, 1])) as tf.Tensor;
  return (await prediction.data())[0];
}
```

### 3. Anomaly Detection

**Flag unusual transactions**:

```typescript
async function detectAnomalies(threshold = 2.0): Promise<Transaction[]> {
  const result = await pool.query(`
    WITH stats AS (
      SELECT
        category,
        AVG(ABS(amount)) as avg_amount,
        STDDEV(ABS(amount)) as stddev_amount
      FROM finance.transactions
      WHERE amount < 0
      GROUP BY category
    )
    SELECT t.*, s.avg_amount, s.stddev_amount
    FROM finance.transactions t
    JOIN stats s ON t.category = s.category
    WHERE ABS(t.amount) > s.avg_amount + ($1 * s.stddev_amount)
    AND t.date >= NOW() - INTERVAL '30 days'
    ORDER BY t.date DESC
  `, [threshold]);

  return result.rows;
}
```

### 4. Natural Language Query Parser

**Allow free-form questions**:

```typescript
async function parseNaturalQuery(query: string): Promise<ToolCall> {
  // Use Claude API to parse natural language into structured tool calls
  // Example: "show me food expenses over $50 last week"
  // → { tool: "get_transactions", args: { category: "Food", min_amount: 50, period: "week" }}
}
```

---

## CLI Tool (Simpler Alternative)

If you want something **simpler than MCP**, create a CLI tool:

**File: `nexus-cli.sh`**

```bash
#!/bin/bash
# Nexus CLI - Quick data queries

DB_HOST="nexus.rfanw"
DB_USER="nexus"
DB_NAME="nexus"
DB_PASSWORD="XRtRxHAtSXCYK2OLK2C9Fu8Ak6PhuwiI"

psql_query() {
    PGPASSWORD="$DB_PASSWORD" psql -h "$DB_HOST" -U "$DB_USER" -d "$DB_NAME" -t -c "$1"
}

case "$1" in
    spending)
        echo "📊 Spending Summary (This Month)"
        psql_query "
            SELECT
                category,
                COUNT(*) as transactions,
                TO_CHAR(SUM(ABS(amount)), 'FM999,999.00') as spent
            FROM finance.transactions
            WHERE amount < 0
            AND date >= date_trunc('month', CURRENT_DATE)
            GROUP BY category
            ORDER BY SUM(ABS(amount)) DESC
        " | column -t
        ;;

    budget)
        echo "💰 Budget Status"
        psql_query "
            SELECT
                b.category,
                TO_CHAR(b.budget_amount, 'FM999,999') as budget,
                TO_CHAR(COALESCE(SUM(ABS(t.amount)), 0), 'FM999,999') as spent,
                TO_CHAR(b.budget_amount - COALESCE(SUM(ABS(t.amount)), 0), 'FM999,999') as remaining,
                ROUND((COALESCE(SUM(ABS(t.amount)), 0) / b.budget_amount * 100), 0) || '%' as used
            FROM finance.budgets b
            LEFT JOIN finance.transactions t ON b.category = t.category
                AND t.amount < 0
                AND DATE_TRUNC('month', t.date) = DATE_TRUNC('month', b.month)
            WHERE DATE_TRUNC('month', b.month) = DATE_TRUNC('month', CURRENT_DATE)
            GROUP BY b.category, b.budget_amount
        " | column -t
        ;;

    recurring)
        echo "🔄 Recurring Transactions"
        psql_query "
            SELECT DISTINCT ON (merchant_name)
                merchant_name,
                COUNT(*) as occurrences,
                TO_CHAR(AVG(ABS(amount)), 'FM999.00') as avg_amount,
                TO_CHAR(MAX(date), 'YYYY-MM-DD') as last_date
            FROM finance.transactions
            WHERE amount < 0
            GROUP BY merchant_name
            HAVING COUNT(*) >= 3
            ORDER BY merchant_name, COUNT(*) DESC
            LIMIT 10
        " | column -t
        ;;

    top)
        echo "🏆 Top Expenses (This Month)"
        psql_query "
            SELECT
                TO_CHAR(date, 'MM-DD') as date,
                merchant_name,
                category,
                TO_CHAR(ABS(amount), 'FM999.00') as amount
            FROM finance.transactions
            WHERE amount < 0
            AND date >= date_trunc('month', CURRENT_DATE)
            ORDER BY ABS(amount) DESC
            LIMIT 10
        " | column -t
        ;;

    export)
        echo "📦 Exporting data to JSON..."
        psql_query "
            SELECT json_agg(row_to_json(t.*))
            FROM (
                SELECT * FROM finance.transactions
                WHERE date >= NOW() - INTERVAL '30 days'
                ORDER BY date DESC
            ) t
        " > nexus-export-$(date +%Y%m%d).json
        echo "✅ Exported to nexus-export-$(date +%Y%m%d).json"
        ;;

    *)
        echo "Nexus CLI - Query your personal data"
        echo ""
        echo "Usage: nexus-cli <command>"
        echo ""
        echo "Commands:"
        echo "  spending   - Show spending by category this month"
        echo "  budget     - Show budget status"
        echo "  recurring  - Detect recurring transactions"
        echo "  top        - Top 10 expenses this month"
        echo "  export     - Export last 30 days to JSON"
        ;;
esac
```

**Install**:
```bash
chmod +x nexus-cli.sh
sudo mv nexus-cli.sh /usr/local/bin/nexus
```

**Use**:
```bash
nexus spending
nexus budget
nexus recurring
```

Then in Claude Code:
```bash
claude

> Run `nexus spending` and analyze my spending patterns

# Claude runs the command, sees the output, and provides analysis
```

---

## Comparison: MCP vs CLI

| Feature | MCP Server | CLI Tool |
|---------|-----------|----------|
| **Ease of setup** | Medium | Easy |
| **Claude integration** | Native, seamless | Manual (paste output) |
| **Sophistication** | High (semantic operations) | Low (raw queries) |
| **Extensibility** | Excellent | Limited |
| **Performance** | Can add caching/optimization | Direct SQL |
| **Learning curve** | Moderate | Low |
| **Best for** | Natural conversations | Quick ad-hoc queries |

**Recommendation**: Start with **CLI tool** (30 min), upgrade to **MCP server** later (2-3 hours)

---

## Next Steps

### Phase 1: Quick Win (Today - 30 min)
1. Create `nexus-cli.sh` with 5-6 commands
2. Install as `/usr/local/bin/nexus`
3. Test with Claude Code

### Phase 2: MCP Server (This Weekend - 3 hours)
1. Set up TypeScript project
2. Implement 5 core tools
3. Configure Claude Code
4. Test natural language queries

### Phase 3: Advanced Features (Next Week)
1. Add caching layer (Redis)
2. Implement ML predictions
3. Add anomaly detection
4. Create visualization endpoints

---

## Expected User Experience

### With CLI Tool:
```bash
claude

> Run `nexus spending` and tell me where I'm overspending

Claude runs the command, analyzes output, provides insights
```

### With MCP Server:
```bash
claude

> How much did I spend on food last month compared to my budget?

Claude: "Let me check your spending data..."
[Automatically calls get_spending_summary and get_budget_status]
Claude: "You spent AED 2,450 on food last month, which is 22% over your
AED 2,000 budget. Your biggest food expenses were..."
```

Much more natural! 🎯

---

## Implementation Priority

**Must Have** (Phase 1):
- [ ] Basic CLI tool with 5-6 queries
- [ ] Export to JSON/CSV
- [ ] Connection to Claude Code

**Should Have** (Phase 2):
- [ ] MCP server with 10 tools
- [ ] Semantic queries
- [ ] Error handling
- [ ] Input validation

**Nice to Have** (Phase 3):
- [ ] ML predictions
- [ ] Anomaly detection
- [ ] Caching layer
- [ ] Rate limiting
- [ ] Query history

---

**Time to implement CLI**: 30 minutes
**Time to implement MCP**: 3 hours
**Value**: Unlimited! 🚀

Let's build this! Which approach do you want to start with?
