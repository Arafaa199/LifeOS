# Nexus Finance - Enhanced Features Guide

## 🎉 New Features Added

Your Nexus finance module now includes comprehensive expense tracking, budgeting, analytics, and AI-powered insights!

### Mobile App Features

#### 1. **Quick Tab** - Fast Expense Logging
- ✅ Natural language expense entry ("$45 at Whole Foods")
- ✅ Budget alerts (warnings when approaching/exceeding budget)
- ✅ Today's spending summary with category breakdown
- ✅ Quick category shortcuts
- ✅ Manual expense entry button
- ✅ Recent transactions preview

#### 2. **Transactions Tab** - Advanced Transaction Management
- ✅ **Search transactions** by merchant, category, or notes
- ✅ **Filter by category** with visual chips
- ✅ **Tap transaction** to view full details
- ✅ **Edit transactions** - change amount, category, date, notes
- ✅ **Delete transactions** with confirmation
- ✅ **CSV Export** - export all transactions to file
- ✅ Pull to refresh
- ✅ Transaction count when filtered

#### 3. **Budget Tab** - Budget Management & Analytics
- ✅ Set monthly budgets by category
- ✅ Visual progress bars (green when under, red when over)
- ✅ Budget percentage and remaining amount
- ✅ **Spending charts** (pie + bar charts)
  - iOS 16+: Native SwiftUI charts
  - iOS 15: Custom progress bars
- ✅ Category breakdown with amounts
- ✅ Add/edit/delete budgets
- ✅ Real-time updates

#### 4. **Insights Tab** - AI-Powered Analytics ⭐ NEW
- ✅ **Quick Stats Dashboard**
  - Total transactions
  - Average per transaction
  - Active categories
  - Monthly spending

- ✅ **Top Merchants**
  - See where you spend most
  - Transaction count per merchant
  - Total spending per merchant

- ✅ **AI Insights** (Claude-powered)
  - Personalized spending analysis
  - Budget warnings
  - Actionable recommendations
  - Positive observations
  - Refresh for updated insights

- ✅ **Spending Patterns**
  - Most active day of week
  - Average daily spend
  - Largest category

- ✅ **Monthly Trends** (detailed view)
  - 3/6/12 month comparison
  - Line chart with spending trend
  - Month-over-month change percentage
  - Category trends with indicators
  - Visual month comparison cards

### Backend Features

#### New Webhooks Created

1. **Update Transaction** - `POST /webhook/nexus-update-transaction`
2. **Delete Transaction** - `DELETE /webhook/nexus-delete-transaction/:id`
3. **AI Insights** - `POST /webhook/nexus-insights`
4. **Monthly Trends** - `GET /webhook/nexus-monthly-trends?months=N`

#### Existing Webhooks
- Finance Summary - `GET /webhook/nexus-finance-summary`
- Log Expense - `POST /webhook/nexus-expense`
- Add Transaction - `POST /webhook/nexus-transaction`
- Set Budget - `POST /webhook/nexus-set-budget`
- Fetch Budgets - `GET /webhook/nexus-budgets`
- Delete Budget - `DELETE /webhook/nexus-budget/:id`
- Trigger SMS Import - `POST /webhook/nexus-trigger-import`

## 📦 Setup Instructions

### Step 1: Import ALL n8n Workflows

Import these workflows to https://n8n.rfanw:

**Budget Workflows** (Updated):
- `budget-set-webhook.json` ⭐ UPDATED
- `budget-fetch-webhook.json` ⭐ UPDATED
- `budget-delete-webhook.json`

**Transaction Workflows** (New):
- `transaction-update-webhook.json` ⭐ NEW
- `transaction-delete-webhook.json` ⭐ NEW

**Analytics Workflows** (New):
- `insights-webhook.json` ⭐ NEW
- `monthly-trends-webhook.json` ⭐ NEW

**Summary Workflow** (Updated):
- `finance-summary-webhook.json` ⭐ UPDATED

**Remember to ACTIVATE all workflows after importing!**

### Step 2: Database Setup

The budgets table should already be created. Verify:

```sql
-- Check budgets table exists
\dt finance.budgets

-- If not, create it
CREATE TABLE IF NOT EXISTS finance.budgets (
    id SERIAL PRIMARY KEY,
    month DATE NOT NULL,
    category VARCHAR(50) NOT NULL,
    budget_amount DECIMAL(10,2) NOT NULL,
    UNIQUE(month, category)
);

CREATE INDEX IF NOT EXISTS idx_budgets_month ON finance.budgets(month);
CREATE INDEX IF NOT EXISTS idx_budgets_category ON finance.budgets(category);
```

### Step 3: Build & Run Mobile App

```bash
cd /Users/rafa/Cyber/Dev/Nexus-mobile
open Nexus.xcodeproj
# In Xcode: Product > Run
```

## 🎯 Feature Walkthrough

### Search & Filter Transactions

1. Go to **Finance → Transactions**
2. **Search**: Type merchant name, category, or notes
3. **Filter**: Tap category chips at top (Food, Transport, etc.)
4. **View Details**: Tap any transaction

### Edit Transaction

1. Tap transaction → Shows detail view
2. Tap "Edit Transaction"
3. Modify merchant, amount, category, date, or notes
4. Tap "Save Changes"
5. Updates reflect immediately

### Delete Transaction

1. Tap transaction → Shows detail view
2. Tap "Delete Transaction" (red button)
3. Confirm deletion
4. Transaction removed from list

### Export to CSV

1. Go to **Finance → Transactions**
2. Tap share icon (top-right)
3. Choose where to save/share
4. Opens in Files, Email, AirDrop, etc.

### Set Budget

1. Go to **Finance → Budget**
2. Tap "Set Budgets" (or "Manage" if budgets exist)
3. Tap "+" to add new budget
4. Select category and enter amount
5. Budget applies to current month
6. See progress bar and spending percentage

### View Budget Alerts

1. Go to **Finance → Quick**
2. If any budget is at 80%+ usage, you'll see:
   - **Orange warning**: 80-100% used
   - **Red alert**: Over budget (100%+)
3. Shows category and amount over/percentage

### Generate AI Insights

1. Go to **Finance → Insights**
2. Tap "Generate AI Insights" (or refresh icon)
3. Claude analyzes your spending and provides:
   - Spending patterns
   - Budget warnings
   - Recommendations
   - Positive observations

### View Monthly Trends

1. Go to **Finance → Insights**
2. Tap "View Monthly Trends"
3. Select period (3/6/12 months)
4. See:
   - Line chart of spending trend
   - Month-over-month comparison
   - Percentage change
   - Category trends

### View Top Merchants

1. Go to **Finance → Insights**
2. Scroll to "Top Merchants" section
3. See top 5 merchants by spending
4. Shows transaction count and total spent

## 🧪 Testing Checklist

- [ ] Search transactions by merchant name
- [ ] Filter transactions by category
- [ ] Tap transaction to view details
- [ ] Edit a transaction and save
- [ ] Delete a transaction
- [ ] Export transactions to CSV
- [ ] Set a new budget
- [ ] View budget alert (if over 80%)
- [ ] Generate AI insights
- [ ] View monthly trends
- [ ] Check top merchants
- [ ] Check spending patterns
- [ ] View quick stats

## 📊 New UI Components

### Filter Chips
Horizontal scrolling category filters at top of Transactions tab.
- Tap to filter by category
- "All" chip shows all transactions
- Selected chip is blue

### Transaction Detail View
Full-screen modal when tapping transaction:
- All transaction fields
- Edit button
- Delete button (red)
- Tags and flags display

### Stat Cards
Colored cards showing key metrics:
- Icon + Title + Value
- Used in Insights tab

### Pattern Cards
Cards showing spending patterns:
- Icon + Description + Value
- Most active day, average spend, etc.

### Month Comparison Cards
Side-by-side cards comparing months:
- Current month (blue background)
- Previous month (gray)
- Change indicator (arrow + percentage)

### Monthly Trends Chart
- iOS 16+: Line + area chart
- iOS 15: Horizontal bar chart
- Interactive and scrollable

## 🔧 Troubleshooting

### Insights not loading
- Check that insights-webhook.json is activated in n8n
- Verify Claude AI credentials in n8n
- Check n8n execution logs for errors

### Monthly trends showing no data
- Ensure monthly-trends-webhook.json is activated
- Verify you have transactions spanning multiple months
- Check PostgreSQL query is returning data

### Edit/delete not working
- Activate transaction-update-webhook.json and transaction-delete-webhook.json
- Verify transaction ID is being passed correctly
- Check n8n logs for errors

### Search not working
- Search works offline (no backend needed)
- Transactions must be loaded first
- Try pull-to-refresh on Transactions tab

### Budget alerts not showing
- Budgets must be set for current month
- Spending must exceed 80% of budget
- Check finance-summary-webhook returns budgets

## 💡 Pro Tips

1. **Quick Add**: Use Quick tab for fast expense logging
2. **Search**: Search works on merchant, category, AND notes
3. **CSV Export**: Export monthly for record keeping
4. **AI Insights**: Refresh weekly for updated analysis
5. **Trends**: Use 12-month view for long-term patterns
6. **Budgets**: Set realistic budgets based on past spending
7. **Categories**: Consistent category names help with budgeting
8. **Top Merchants**: Identify subscription services to cancel

## 🎨 Customization

### Change Budget Alert Threshold

Currently alerts show at 80% usage. To change:

1. Open `FinanceView.swift`
2. Find `nearBudgetCategories` computed property
3. Change `percentage >= 0.8` to desired threshold

### Modify Insights Prompt

To customize AI insights:

1. Edit `insights-webhook.json`
2. Modify Claude AI node prompt
3. Re-import to n8n

### Adjust Monthly Trends Period

Default periods: 3, 6, 12 months

1. Open `MonthlyTrendsView.swift`
2. Add new case to `Period` enum
3. Rebuild app

## 📈 Analytics Summary

### What Data Is Tracked

- Transaction amount and date
- Merchant name
- Category and subcategory
- Flags (grocery, restaurant)
- Notes and tags
- Currency (AED/SAR/JOD)

### What Insights Are Generated

- Spending patterns by day of week
- Average transaction amount
- Average daily spending
- Top spending categories
- Top merchants
- Budget vs. actual comparison
- Month-over-month trends
- Category trends

### Privacy

- All data stays on your server
- AI insights use Claude via n8n (your API key)
- No third-party analytics
- Export your data anytime (CSV)

## 🚀 Future Enhancements (Not Implemented Yet)

These would be great additions:

- [ ] Recurring expense detection
- [ ] Receipt photo attachment
- [ ] Split expenses with others
- [ ] Income tracking
- [ ] Savings goals
- [ ] Push notifications for budgets
- [ ] Weekly spending reports
- [ ] Custom date range selection
- [ ] Multi-account support
- [ ] Investment tracking

## 📝 API Reference

### Update Transaction

```bash
curl -X POST https://n8n.rfanw/webhook/nexus-update-transaction \
  -H "Content-Type: application/json" \
  -d '{
    "id": 123,
    "merchant_name": "Updated Merchant",
    "amount": 50.00,
    "category": "Food",
    "notes": "Updated notes",
    "date": "2026-01-20T10:00:00Z"
  }'
```

### Delete Transaction

```bash
curl -X DELETE https://n8n.rfanw/webhook/nexus-delete-transaction/123
```

### Get AI Insights

```bash
curl -X POST https://n8n.rfanw/webhook/nexus-insights \
  -H "Content-Type: application/json" \
  -d '{
    "summary": "Total spent: AED 2500\nCategories:\n- Food: AED 600\n- Transport: AED 300\n..."
  }'
```

### Get Monthly Trends

```bash
# Last 3 months (default)
curl https://n8n.rfanw/webhook/nexus-monthly-trends

# Last 6 months
curl https://n8n.rfanw/webhook/nexus-monthly-trends?months=6

# Last 12 months
curl https://n8n.rfanw/webhook/nexus-monthly-trends?months=12
```

## 📁 Files Modified/Created

### New Files Created

**Views:**
- `TransactionDetailView.swift` - Transaction detail and edit screen
- `InsightsView.swift` - AI insights and analytics
- `MonthlyTrendsView.swift` - Monthly spending trends

**Workflows:**
- `transaction-update-webhook.json`
- `transaction-delete-webhook.json`
- `insights-webhook.json`
- `monthly-trends-webhook.json`

### Modified Files

**Views:**
- `FinanceView.swift` - Added Insights tab, filter chips
- `BudgetSettingsView.swift` - Connected to backend

**Models:**
- `FinanceModels.swift` - Added UpdateTransactionRequest, InsightsRequest/Response, MonthlyTrendsResponse, MonthlySpending

**Services:**
- `NexusAPI.swift` - Added updateTransaction, deleteTransaction, getSpendingInsights, fetchMonthlyTrends

**ViewModels:**
- `FinanceViewModel.swift` - Added updateTransaction, deleteTransaction methods

**Workflows (Updated):**
- `budget-set-webhook.json` - Fixed date handling
- `budget-fetch-webhook.json` - Fixed date handling
- `finance-summary-webhook.json` - Fixed date handling

---

**Total Features**: 20+ new features added!
**Last Updated**: 2026-01-20
**Status**: ✅ Ready for testing
