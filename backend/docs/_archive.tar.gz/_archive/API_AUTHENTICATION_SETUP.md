# Nexus API Authentication Setup Guide

## Overview
This guide walks you through securing your Nexus webhooks with API key authentication.

**Generated API Key**: `3f62259deac4aa96427ba0048c3addfe1924f872586d8371d6adfb3d2db3afd8`

---

## Step 1: Configure Mobile App

### Option A: Using Settings UI (Recommended)
1. Open the Nexus iOS app
2. Go to Settings
3. Add a new setting for "API Key" (you may need to add this to your settings view)
4. Enter: `3f62259deac4aa96427ba0048c3addfe1924f872586d8371d6adfb3d2db3afd8`

### Option B: Manual Configuration
Run this in Terminal to set the API key in the simulator:
```bash
xcrun simctl spawn booted defaults write com.yourcompany.Nexus nexusAPIKey "3f62259deac4aa96427ba0048c3addfe1924f872586d8371d6adfb3d2db3afd8"
```

For a physical device, you'll need to add a settings UI or hardcode temporarily for testing.

---

## Step 2: Update n8n Workflows

You need to add API key validation to **all 12 workflows**. Here's how:

### Workflows to Update:
1. nexus-expense
2. nexus-transaction
3. nexus-update-transaction
4. nexus-delete-transaction
5. nexus-income
6. nexus-finance-summary
7. nexus-budgets
8. nexus-set-budget
9. nexus-budget (delete)
10. nexus-insights
11. nexus-monthly-trends
12. nexus-trigger-import

### Adding API Key Check (Manual Steps):

For each workflow:

1. **Open n8n web UI**: https://n8n.rfanw
2. **Open the workflow** (e.g., "nexus-expense")
3. **Add an IF node** right after the Webhook node:
   - Click "+" after the Webhook node
   - Select "IF" node
   - Name it: "API Key Check"

4. **Configure the IF node**:
   - **Condition 1**:
     - Field: `{{ $json.headers["x-api-key"] }}`
     - Operation: `Equal`
     - Value: `3f62259deac4aa96427ba0048c3addfe1924f872586d8371d6adfb3d2db3afd8`

5. **Connect the true path** to your existing workflow logic
6. **Connect the false path** to a "Respond to Webhook" node:
   - Click "+" on the false path
   - Select "Respond to Webhook"
   - Set:
     - Response Code: `401`
     - Response Body: `{ "success": false, "error": "Unauthorized: Invalid API key" }`

7. **Save the workflow**

8. **Repeat for all 12 workflows**

### Example Workflow Structure:
```
Webhook → IF (API Key Check) → [True] → Your Logic → Respond
                              → [False] → 401 Error Response
```

---

## Step 3: Test Authentication

### Test with API Key (Should Succeed):
```bash
curl -X POST https://n8n.rfanw/webhook/nexus-expense \
  -H "Content-Type: application/json" \
  -H "X-API-Key: 3f62259deac4aa96427ba0048c3addfe1924f872586d8371d6adfb3d2db3afd8" \
  -d '{"text": "test expense 10 AED"}'
```

Expected: `{"success": true, ...}`

### Test without API Key (Should Fail):
```bash
curl -X POST https://n8n.rfanw/webhook/nexus-expense \
  -H "Content-Type: application/json" \
  -d '{"text": "test expense 10 AED"}'
```

Expected: `{"success": false, "error": "Unauthorized: Invalid API key"}`

---

## Step 4: Update Mobile App Settings

If you don't have a settings UI for the API key yet, add one:

1. **Update SettingsView.swift** to include:
```swift
Section("API Configuration") {
    SecureField("API Key", text: $apiKey)
        .onChange(of: apiKey) { newValue in
            UserDefaults.standard.set(newValue, forKey: "nexusAPIKey")
        }
}
```

2. **Add the binding**:
```swift
@State private var apiKey = UserDefaults.standard.string(forKey: "nexusAPIKey") ?? ""
```

---

## Step 5: Deploy to Server

Copy the updated .env file to your server:
```bash
scp /Users/rafa/Cyber/Infrastructure/Nexus-setup/.env nexus:/var/www/nexus/.env
```

---

## Security Notes

- **CRITICAL**: The API key is now stored in:
  - Server: `/var/www/nexus/.env`
  - Local: `/Users/rafa/Cyber/Infrastructure/Nexus-setup/.env`
  - Mobile: UserDefaults (encrypted on device)

- **DO NOT** commit the API key to git
- **DO NOT** share the API key publicly
- To rotate the key: Generate a new one with `openssl rand -hex 32` and update all locations

---

## Verification Checklist

- [ ] API key added to .env file
- [ ] API key set in mobile app (UserDefaults)
- [ ] All 12 n8n workflows updated with API key check
- [ ] Test successful request with API key
- [ ] Test failed request without API key
- [ ] Mobile app can successfully make requests
- [ ] Settings UI added for API key management (optional)

---

## Troubleshooting

### Mobile app requests fail with 401:
- Verify API key is set in UserDefaults
- Check the key matches exactly (no spaces/newlines)
- Ensure NexusAPI.swift is using the key from UserDefaults

### n8n workflow doesn't check API key:
- Verify IF node is positioned correctly (right after Webhook)
- Check the header name is exactly `x-api-key` (lowercase)
- Ensure false path leads to 401 response

### Can't find workflows in n8n:
- All workflows should be imported already
- Check https://n8n.rfanw/workflows
- Look for workflows with "nexus-" prefix
