# Nexus Health Sync - iOS Shortcut Setup

## Webhook Endpoint
```
POST https://n8n.rfanw/webhook/health
```

## Quick Setup (Copy-Paste Ready)

### Option 1: Daily Health Sync Shortcut

Create a new Shortcut with these actions:

1. **Find Health Samples** (Steps)
   - Type: Steps
   - Start Date: Start of Today
   - End Date: Current Date
   - Group By: Day

2. **Set Variable** `steps` to Health Samples

3. **Find Health Samples** (Weight)
   - Type: Weight
   - Start Date: 1 week ago
   - End Date: Current Date
   - Sort By: Start Date (Descending)
   - Limit: 1

4. **Set Variable** `weight` to Health Samples

5. **Find Health Samples** (Resting Heart Rate)
   - Type: Resting Heart Rate
   - Start Date: Start of Today
   - End Date: Current Date
   - Limit: 1

6. **Set Variable** `rhr` to Health Samples

7. **Find Health Samples** (Heart Rate Variability)
   - Type: Heart Rate Variability
   - Start Date: Start of Today
   - End Date: Current Date
   - Limit: 1

8. **Set Variable** `hrv` to Health Samples

9. **Find Health Samples** (Active Energy)
   - Type: Active Energy
   - Start Date: Start of Today
   - End Date: Current Date
   - Group By: Day

10. **Set Variable** `calories` to Health Samples

11. **Get Contents of URL**
    - URL: `https://n8n.rfanw/webhook/health`
    - Method: POST
    - Request Body: JSON
    - Body:
    ```json
    {
      "metrics": [
        {
          "type": "steps",
          "value": [steps.Value],
          "unit": "count",
          "date": "[Current Date, format: yyyy-MM-dd]"
        },
        {
          "type": "weight",
          "value": [weight.Value],
          "unit": "kg",
          "date": "[Current Date, format: yyyy-MM-dd]"
        },
        {
          "type": "resting_hr",
          "value": [rhr.Value],
          "unit": "bpm",
          "date": "[Current Date, format: yyyy-MM-dd]"
        },
        {
          "type": "hrv",
          "value": [hrv.Value],
          "unit": "ms",
          "date": "[Current Date, format: yyyy-MM-dd]"
        },
        {
          "type": "active_calories",
          "value": [calories.Value],
          "unit": "kcal",
          "date": "[Current Date, format: yyyy-MM-dd]"
        }
      ]
    }
    ```

12. **Show Notification**: "Health synced to Nexus"

### Automation Setup

1. Go to **Shortcuts** > **Automation** tab
2. Tap **+** > **Create Personal Automation**
3. Select **Time of Day**
4. Set time to **10:00 PM** (after your day's data is complete)
5. Select **Daily**
6. Tap **Next** > **Run Shortcut** > Select "Nexus Health Sync"
7. Turn OFF "Ask Before Running"
8. Tap **Done**

---

## Option 2: Health Auto Export App (Recommended for Full Automation)

For automatic background sync without manual intervention:

1. Install **Health Auto Export** from App Store (~$3)
2. Open app > **Automations** > **Add New**
3. Configure:
   - **Trigger**: Daily at 10 PM
   - **Export**: REST API
   - **URL**: `https://n8n.rfanw/webhook/health`
   - **Method**: POST
   - **Format**: JSON
4. Select metrics:
   - Steps
   - Weight
   - Resting Heart Rate
   - HRV
   - Active Energy
   - Sleep Analysis
   - VO2 Max
   - Respiratory Rate
5. Enable automation

This app runs in the background and syncs automatically.

---

## Supported Metrics

| Metric | Unit | Example |
|--------|------|---------|
| steps | count | 8432 |
| weight | kg | 75.2 |
| resting_hr | bpm | 58 |
| hrv | ms | 45 |
| active_calories | kcal | 450 |
| sleep | min | 420 |
| distance | km | 6.2 |
| floors | count | 12 |
| spo2 | % | 98 |
| vo2max | mL/kg/min | 42 |

---

## Manual Test

You can test the endpoint with curl:

```bash
curl -X POST "https://n8n.rfanw/webhook/health" \
  -H "Content-Type: application/json" \
  -d '{
    "metrics": [
      {"type": "steps", "value": 10000, "unit": "count"},
      {"type": "weight", "value": 75.5, "unit": "kg"}
    ]
  }'
```

Expected response: `{"success":true,"imported":2}`
